import java.util.*

class PizzaFinder(private val ingredientsMap: Map<String, LinkedList<Pizza>>) {

    // map of list of ingredients (as keys) and the corresponding pizza that uses it and how many ingredients does it us as value
    private val cachedResults = mapOf<List<String>, Map<Pizza, Int>>()

    fun findPizzas(ingredients:List<String>): Map<Pizza, Int> {
        if(cachedResults.contains(ingredients)) return cachedResults[ingredients]!!

        cachedResults.keys.first {
            Collections.indexOfSubList(ingredients, it) != -1
        }

        val pizzaWithUsedIngredients = mutableMapOf<Pizza, Int>()
        ingredients.mapNotNull { ingredientsMap[it] }
            .flattenLinkedList()
            .forEach {
                pizzaWithUsedIngredients[it] = (pizzaWithUsedIngredients[it] ?: 0) + 1
            }
    }
}